import java.io.*;
import java.util.*;

class Employee {
    private int id;
    private String name;
    private String position;
    private double salary;

    public Employee(int id, String name, String position, double salary) {
        this.id = id;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return " Employee ID: " + id + "\n Name: " + name + "\n Position: " + position + "\n Salary: $" + salary;
    }
}

public class EmployeeManagement {
    private static final String FILENAME = "employees.txt";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Employee Management System");
            System.out.println("1. Add Employee");
            System.out.println("2. Display Employees");
            System.out.println("3. Delete Employee");
            System.out.println("4. Update Employee Position");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    addEmployee();
                    break;
                case 2:
                    displayEmployees();
                    break;
                case 3:
                    deleteEmployee();
                    break;
                case 4:
                    updateEmployeePosition();
                    break;
                case 5:
                    System.out.println("Exiting the program.");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addEmployee() {
        try {
            FileWriter fileWriter = new FileWriter(FILENAME, true);
            PrintWriter writer = new PrintWriter(fileWriter);

            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter Employee ID: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            System.out.print("Enter Employee Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter Employee Position: ");
            String position = scanner.nextLine();

            System.out.print("Enter Employee Salary: ");
            double salary = scanner.nextDouble();

            Employee employee = new Employee(id, name, position, salary);
            writer.println(employee.getId() + "," + employee.getName() + "," + employee.getPosition() + "," + employee.getSalary());

            writer.close();
            fileWriter.close();

            System.out.println("Employee added successfully!");
        } catch (IOException e) {
            System.out.println("Error: " + e);
        }
    }

    private static void displayEmployees() {
        try {
            FileReader fileReader = new FileReader(FILENAME);
            BufferedReader reader = new BufferedReader(fileReader);

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                String name = parts[1];
                String position = parts[2];
                double salary = Double.parseDouble(parts[3]);
                Employee employee = new Employee(id, name, position, salary);
                System.out.println(employee);
            }

            reader.close();
            fileReader.close();
        } catch (IOException e) {
            System.out.println("Error: " + e);
        }
        System.out.println();
        System.out.println();
    }

    private static void deleteEmployee() {
        try {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter Employee ID to delete: ");
            int idToDelete = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            File inputFile = new File(FILENAME);
            File tempFile = new File("temp.txt");

            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            PrintWriter writer = new PrintWriter(new FileWriter(tempFile));

            String line;
            boolean employeeFound = false;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);

                if (id == idToDelete) {
                    employeeFound = true;
                    continue; // Skip this line to delete the employee
                }

                writer.println(line);
            }

            writer.close();
            reader.close();

            if (employeeFound) {
                boolean successfulRename = tempFile.renameTo(inputFile);
                if (successfulRename) {
                    System.out.println("Employee deleted successfully.");
                } else {
                    System.err.println("Error: Could not update employee data.");
                }
            } else {
                System.out.println("Employee not found.");
            }
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void updateEmployeePosition() {
        try {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter Employee ID to update position: ");
            int idToUpdate = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            System.out.print("Enter new Position: ");
            String newPosition = scanner.nextLine();

            File inputFile = new File(FILENAME);
            File tempFile = new File("temp.txt");

            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            PrintWriter writer = new PrintWriter(new FileWriter(tempFile));

            String line;
            boolean employeeFound = false;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);

                if (id == idToUpdate) {
                    parts[2] = newPosition; // Update the position
                    line = String.join(",", parts); // Reconstruct the line
                    employeeFound = true;
                }

                writer.println(line);
            }

            writer.close();
            reader.close();

            if (employeeFound) {
                boolean successfulRename = tempFile.renameTo(inputFile);
                if (successfulRename) {
                    System.out.println("Employee position updated successfully.");
                } else {
                    System.err.println("Error: Could not update employee data.");
                }
            } else {
                System.out.println("Employee not found.");
            }
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
